# Stripe Payment Testing Guide

## Test Card Numbers

**Successful Payment:**
- Card: 4242 4242 4242 4242
- Exp: 12/25
- CVC: 123

**Requires Authentication:**
- Card: 4000 0025 0000 3155
- Exp: 12/25
- CVC: 123

**Declined Payment:**
- Card: 4000 0000 0000 0002
- Exp: 12/25
- CVC: 123

## Testing Steps

1. **Navigate to Products**
   - Go to https://3000-iw57eqcarp8ojdfc2gj3v-f9f896ac.sg1.manus.computer/products
   - Select a product (e.g., AI CTO Kit - $397)

2. **Add to Cart & Checkout**
   - Click "Get Bundle" or add product
   - Navigate to /checkout
   - Review order summary

3. **Enter Test Card**
   - Use card: 4242 4242 4242 4242
   - Exp: 12/25, CVC: 123
   - Click "Pay $397.00"

4. **Verify Success**
   - Should see success message
   - Check dashboard for purchase history
   - Verify order in database

5. **Test Failed Payment**
   - Repeat with card: 4000 0000 0000 0002
   - Should see error message
   - Order should not be created

## Webhook Testing

Stripe webhooks are configured at:
- Endpoint: /api/trpc/checkout.handleWebhook
- Events: payment_intent.succeeded, payment_intent.payment_failed

To test locally:
```bash
stripe listen --forward-to localhost:3000/api/trpc/checkout.handleWebhook
```

## Production Checklist

- [ ] Stripe live keys configured
- [ ] Webhook secret configured
- [ ] Test payment successful
- [ ] Test payment failed
- [ ] Order created in database
- [ ] Customer receives confirmation email
- [ ] Dashboard shows purchase history
