# Wise Payment Integration Guide

## Overview

The Vibe Coding Command Center now uses Wise payment links for seamless, secure payment processing. This replaces Stripe with a more straightforward integration using your personal Wise payment links.

## Wise Payment Links Configured

Your Wise payment links are already integrated into the system:

- **Personal Link**: https://wise.com/pay/me/kassandraw7
- **Product Link**: https://wise.com/pay/r/rgOgy006nKFE7XM

## How It Works

### 1. Customer Initiates Checkout
- Customer selects products and clicks "Pay"
- System creates an order in the database with "pending" status
- Order receives unique ID (e.g., Order #1001)

### 2. Payment Session Created
- Backend creates Wise payment session via `trpc.wise.createSession`
- Generates payment link with order reference
- Returns link to frontend

### 3. Customer Redirected to Wise
- Customer clicks "Complete Payment on Wise" button
- Redirected to Wise payment page
- Completes payment securely

### 4. Payment Verification
- Wise sends webhook notification (or manual verification)
- System verifies payment status
- Order status updated to "completed"
- Products delivered automatically

### 5. Product Delivery
- Download links generated
- Email sent with delivery confirmation
- Customer accesses products immediately

## API Endpoints

### Create Payment Session
```typescript
POST /api/trpc/wise.createSession

Input:
{
  products: [
    { productId: 1, quantity: 1 },
    { productId: 2, quantity: 1 }
  ]
}

Response:
{
  success: true,
  session: {
    orderId: 1001,
    userId: 123,
    totalAmount: 497,
    currency: "USD",
    wiseLink: "https://wise.com/pay/r/rgOgy006nKFE7XM?ref=order_1001&amount=497",
    createdAt: "2026-03-23T...",
    expiresAt: "2026-03-24T..."
  }
}
```

### Verify Payment
```typescript
POST /api/trpc/wise.verifyPayment

Input:
{
  orderId: 1001,
  status: "completed" | "failed" | "cancelled"
}

Response:
{
  success: true,
  verification: {
    orderId: 1001,
    status: "completed",
    amount: 497,
    currency: "USD",
    verifiedAt: "2026-03-23T..."
  }
}
```

### Get Payment Status
```typescript
GET /api/trpc/wise.getStatus?orderId=1001

Response:
{
  success: true,
  status: {
    orderId: 1001,
    status: "completed",
    amount: 497,
    currency: "USD",
    verifiedAt: "2026-03-23T..."
  }
}
```

### Webhook Endpoint
```typescript
POST /api/trpc/wise.webhook

Input:
{
  orderId: 1001,
  status: "completed"
}

Response:
{
  success: true,
  verification: { ... }
}
```

## File Structure

### Backend Files
- `server/wise-payment.ts` - Core Wise payment logic
- `server/wise-router.ts` - tRPC router for Wise endpoints
- `server/routers.ts` - Main router (includes wise router)

### Frontend Files
- `client/src/pages/Checkout.tsx` - Updated checkout with Wise integration
- `client/src/pages/WiseCheckout.tsx` - Dedicated Wise checkout page

## Testing the Integration

### 1. Test Checkout Flow
```bash
1. Go to /products
2. Select a product
3. Click "Add to Cart"
4. Click "Checkout"
5. Review order
6. Click "Pay $XXX"
```

### 2. Test Payment Session Creation
```bash
curl -X POST http://localhost:3000/api/trpc/wise.createSession \
  -H "Content-Type: application/json" \
  -d '{
    "products": [
      { "productId": 1, "quantity": 1 }
    ]
  }'
```

### 3. Test Payment Verification
```bash
curl -X POST http://localhost:3000/api/trpc/wise.verifyPayment \
  -H "Content-Type: application/json" \
  -d '{
    "orderId": 1001,
    "status": "completed"
  }'
```

## Order Flow

```
Customer → Checkout Page
    ↓
Select Products & Quantity
    ↓
Review Order Summary
    ↓
Click "Pay with Wise"
    ↓
Create Order (pending status)
    ↓
Generate Wise Payment Link
    ↓
Redirect to Wise
    ↓
Customer Completes Payment
    ↓
Wise Sends Confirmation
    ↓
Verify Payment Status
    ↓
Update Order to "completed"
    ↓
Generate Download Links
    ↓
Send Delivery Email
    ↓
Customer Downloads Products
```

## Database Schema

### Orders Table
```sql
CREATE TABLE orders (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  amount DECIMAL(10, 2),
  currency VARCHAR(3) DEFAULT 'USD',
  status ENUM('pending', 'completed', 'failed', 'cancelled'),
  stripeSessionId VARCHAR(255),
  stripePaymentIntentId VARCHAR(255),
  createdAt TIMESTAMP,
  updatedAt TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);
```

### Order Items Table
```sql
CREATE TABLE order_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  orderId INT NOT NULL,
  productId INT NOT NULL,
  quantity INT DEFAULT 1,
  price DECIMAL(10, 2),
  FOREIGN KEY (orderId) REFERENCES orders(id),
  FOREIGN KEY (productId) REFERENCES products(id)
);
```

## Security Considerations

1. **Order Verification**: Each order is verified before product delivery
2. **Download Tokens**: Unique tokens generated for each purchase
3. **Expiration**: Download links expire after 30 days
4. **User Isolation**: Users can only access their own purchases
5. **HTTPS**: All payment links use secure HTTPS

## Webhook Setup (Optional)

For automatic payment verification, set up a webhook in Wise:

1. Go to Wise Dashboard
2. Settings → Webhooks
3. Add webhook URL: `https://yourdomain.com/api/trpc/wise.webhook`
4. Select events: Payment completed, Payment failed
5. Wise will send POST requests to your webhook

## Troubleshooting

### Payment Link Not Generated
- Check database connection
- Verify order creation in database
- Check server logs for errors

### Payment Not Verified
- Manually call `wise.verifyPayment` endpoint
- Check webhook configuration
- Verify order ID matches

### Download Link Not Working
- Verify product file exists in S3
- Check download token validity
- Ensure 30-day window hasn't expired

### Email Not Sent
- Check email service configuration
- Verify user email address
- Check server logs for errors

## Production Deployment

### Before Going Live

1. **Test Payment Flow**
   - Create test order
   - Verify payment session
   - Test webhook

2. **Configure Wise Links**
   - Update payment links in production
   - Test with live Wise account
   - Verify payment notifications

3. **Set Up Monitoring**
   - Monitor payment failures
   - Track delivery issues
   - Monitor download activity

4. **Enable Webhooks**
   - Configure Wise webhooks
   - Test webhook delivery
   - Set up error alerts

## Support

For Wise support: https://wise.com/support
For application issues: Contact your development team

## Next Steps

1. Test the complete payment flow
2. Configure Wise webhooks for automatic verification
3. Monitor payment processing
4. Gather customer feedback
5. Optimize based on metrics
