/**
 * Wise Payment Integration Service
 * Replaces Stripe with Wise payment links for seamless checkout experience
 */

import * as db from "./db";

export interface WisePaymentConfig {
  personalLink: string; // https://wise.com/pay/me/kassandraw7
  productLink: string; // https://wise.com/pay/r/rgOgy006nKFE7XM
}

export interface WisePaymentSession {
  orderId: number;
  userId: number;
  products: Array<{ productId: number; quantity: number }>;
  totalAmount: number;
  currency: string;
  wiseLink: string;
  createdAt: Date;
  expiresAt: Date;
}

export interface WisePaymentVerification {
  orderId: number;
  status: "pending" | "completed" | "failed" | "cancelled";
  amount: number;
  currency: string;
  verifiedAt?: Date;
}

// Wise payment configuration
const WISE_CONFIG: WisePaymentConfig = {
  personalLink: "https://wise.com/pay/me/kassandraw7",
  productLink: "https://wise.com/pay/r/rgOgy006nKFE7XM",
};

/**
 * Create a Wise payment session for checkout
 */
export async function createWisePaymentSession(
  userId: number,
  products: Array<{ productId: number; quantity: number }>
): Promise<WisePaymentSession> {
  try {
    // Calculate total amount
    let totalAmount = 0;
    const productDetails = [];

    for (const item of products) {
      const product = await db.getProductById(item.productId);
      if (!product) {
        throw new Error(`Product ${item.productId} not found`);
      }
      const price = parseFloat(product.price.toString());
      totalAmount += price * item.quantity;
      productDetails.push({
        productId: item.productId,
        name: product.name,
        price: product.price,
        quantity: item.quantity,
      });
    }

    // Create order in database with pending status
    const orderResult = await db.createOrder({
      userId,
      amount: totalAmount,
      currency: "USD",
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    
    const orderId = (orderResult as any).insertId || orderResult[0];
    const order = await db.getOrderById(orderId);
    if (!order) {
      throw new Error("Failed to create order");
    }

    // Generate Wise payment link with order reference
    const wiseLink = generateWisePaymentLink(
      order.id,
      totalAmount,
      productDetails
    );

    const session: WisePaymentSession = {
      orderId: order.id,
      userId,
      products,
      totalAmount,
      currency: "USD",
      wiseLink,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hour expiry
    };

    return session;
  } catch (error) {
    console.error("Error creating Wise payment session:", error);
    throw error;
  }
}

/**
 * Generate Wise payment link with order details
 */
function generateWisePaymentLink(
  orderId: number,
  amount: number,
  products: any[]
): string {
  const productNames = products.map((p) => p.name).join(", ");
  const description = `Order #${orderId}: ${productNames}`;

  // Use the product link for batch payments
  // In production, you would use Wise API to create custom links
  // For now, we'll use the configured links with order reference
  const baseLink = WISE_CONFIG.productLink;

  // Append order reference as query parameter
  const link = `${baseLink}?ref=order_${orderId}&amount=${amount}&desc=${encodeURIComponent(description)}`;

  return link;
}

/**
 * Verify Wise payment completion
 * In production, this would be called by a webhook from Wise
 */
export async function verifyWisePayment(
  orderId: number,
  paymentStatus: "completed" | "failed" | "cancelled"
): Promise<WisePaymentVerification> {
  try {
    const order = await db.getOrderById(orderId);
    if (!order) {
      throw new Error("Order not found");
    }

    // Update order status
    await db.updateOrderStatus(
      orderId,
      paymentStatus === "completed" ? "completed" : "failed"
    );

    // If payment successful, deliver products
    if (paymentStatus === "completed") {
      const user = await db.getUserById(order.userId);
      if (user && user.email) {
        // Get order items and deliver each product
        const orderItems = await db.getOrderItems(orderId);
        for (const item of orderItems) {
          if (item.productId) {
            await deliverProductAfterWisePayment(
              order.userId,
              item.productId,
              orderId,
              user.email
            );
          }
        }
      }
    }

    return {
      orderId,
      status: paymentStatus,
      amount: parseFloat(order.amount.toString()),
      currency: "USD",
      verifiedAt: new Date(),
    };
  } catch (error) {
    console.error("Error verifying Wise payment:", error);
    throw error;
  }
}

/**
 * Deliver product after Wise payment verification
 */
async function deliverProductAfterWisePayment(
  userId: number,
  productId: number,
  orderId: number,
  userEmail: string
): Promise<void> {
  try {
    const product = await db.getProductById(productId);
    if (!product) {
      throw new Error("Product not found");
    }

    // Generate unique download token
    const downloadToken = `wise_${userId}_${productId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Create product purchase record
    await db.createProductPurchase({
      userId,
      productId,
      orderId,
      downloadToken,
      downloadCount: 0,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      purchasedAt: new Date(),
    });

    // Send delivery email
    const downloadUrl = product.fileUrl || "";
    await sendWisePaymentDeliveryEmail(
      userEmail,
      product.name,
      downloadUrl,
      downloadToken
    );

    console.log(
      `Product ${productId} delivered to user ${userId} after Wise payment`
    );
  } catch (error) {
    console.error("Error delivering product after Wise payment:", error);
  }
}

/**
 * Send delivery email after Wise payment
 */
async function sendWisePaymentDeliveryEmail(
  email: string,
  productName: string,
  downloadUrl: string,
  downloadToken: string
): Promise<void> {
  try {
    // In production, integrate with email service
    console.log(`Sending delivery email to ${email} for ${productName}`);
    console.log(`Download URL: ${downloadUrl}`);
    console.log(`Download Token: ${downloadToken}`);
  } catch (error) {
    console.error("Error sending delivery email:", error);
  }
}

/**
 * Get Wise payment status for order
 */
export async function getWisePaymentStatus(
  orderId: number
): Promise<WisePaymentVerification | null> {
  try {
    const order = await db.getOrderById(orderId);
    if (!order) {
      return null;
    }

    return {
      orderId,
      status: (order.status as any) || "pending",
      amount: parseFloat(order.amount.toString()),
      currency: "USD",
      verifiedAt: order.updatedAt,
    };
  } catch (error) {
    console.error("Error getting Wise payment status:", error);
    return null;
  }
}

/**
 * Cancel Wise payment session
 */
export async function cancelWisePaymentSession(orderId: number): Promise<void> {
  try {
    await db.updateOrderStatus(orderId, "cancelled");
    console.log(`Wise payment session cancelled for order ${orderId}`);
  } catch (error) {
    console.error("Error cancelling Wise payment session:", error);
  }
}

/**
 * Get Wise payment configuration
 */
export function getWisePaymentConfig(): WisePaymentConfig {
  return WISE_CONFIG;
}

/**
 * Format amount for Wise payment
 */
export function formatWiseAmount(amount: number): string {
  return amount.toFixed(2);
}

/**
 * Validate Wise payment webhook
 * In production, verify webhook signature from Wise
 */
export function validateWiseWebhook(
  payload: any,
  signature: string
): boolean {
  // TODO: Implement proper webhook validation with Wise
  // For now, accept all webhooks (NOT SECURE - implement in production)
  return true;
}

export default {
  createWisePaymentSession,
  verifyWisePayment,
  getWisePaymentStatus,
  cancelWisePaymentSession,
  getWisePaymentConfig,
  formatWiseAmount,
  validateWiseWebhook,
};
