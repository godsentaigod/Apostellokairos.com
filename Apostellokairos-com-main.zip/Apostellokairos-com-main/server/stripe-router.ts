import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as stripePayment from "./stripe-payment";

export const stripeRouter = router({
  /**
   * Create a Stripe checkout session
   */
  createSession: publicProcedure
    .input(
      z.object({
        products: z.array(
          z.object({
            productId: z.number(),
            quantity: z.number().min(1),
          })
        ),
        guestEmail: z.string().email().optional(),
        guestName: z.string().optional(),
        returnUrl: z.string().url().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const session = await stripePayment.createStripeCheckoutSession(
          input.products,
          {
            guestEmail: input.guestEmail,
            guestName: input.guestName,
            returnUrl: input.returnUrl,
          }
        );

        return {
          success: true,
          session: {
            sessionId: session.sessionId,
            orderId: session.orderId,
            checkoutUrl: session.checkoutUrl,
            totalAmount: session.totalAmount,
            currency: session.currency,
          },
        };
      } catch (error) {
        console.error("Stripe session creation error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Failed to create checkout session",
        };
      }
    }),

  /**
   * Verify payment status
   */
  verifyPayment: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const verification = await stripePayment.verifyStripePayment(
          input.sessionId
        );

        return {
          success: true,
          verification,
        };
      } catch (error) {
        console.error("Payment verification error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Failed to verify payment",
        };
      }
    }),

  /**
   * Get payment status for an order
   */
  getPaymentStatus: publicProcedure
    .input(
      z.object({
        orderId: z.number(),
      })
    )
    .query(async ({ input }) => {
      try {
        const status = await stripePayment.getPaymentStatus(input.orderId);

        if (!status) {
          return {
            success: false,
            error: "Payment not found",
          };
        }

        return {
          success: true,
          status,
        };
      } catch (error) {
        console.error("Error getting payment status:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Failed to get payment status",
        };
      }
    }),

  /**
   * Cancel a checkout session
   */
  cancelSession: publicProcedure
    .input(
      z.object({
        sessionId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await stripePayment.cancelCheckoutSession(input.sessionId);

        return {
          success: true,
          message: "Checkout session cancelled",
        };
      } catch (error) {
        console.error("Session cancellation error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Failed to cancel session",
        };
      }
    }),

  /**
   * Get Stripe publishable key for frontend
   */
  getPublishableKey: publicProcedure.query(() => {
    try {
      const key = stripePayment.getStripePublishableKey();
      return {
        success: true,
        publishableKey: key,
      };
    } catch (error) {
      console.error("Error getting publishable key:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Failed to get publishable key",
      };
    }
  }),
});
