/**
 * Wise Payment Router
 * tRPC endpoints for Wise payment processing
 */

import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  createWisePaymentSession,
  verifyWisePayment,
  getWisePaymentStatus,
  cancelWisePaymentSession,
  getWisePaymentConfig,
} from "./wise-payment";

export const wiseRouter = router({
  /**
   * Create a Wise payment session for checkout
   */
  createSession: protectedProcedure
    .input(
      z.object({
        products: z.array(
          z.object({
            productId: z.number(),
            quantity: z.number().min(1),
          })
        ),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const session = await createWisePaymentSession(
          ctx.user.id,
          input.products
        );
        return {
          success: true,
          session,
        };
      } catch (error) {
        console.error("Error creating Wise payment session:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Verify Wise payment completion
   */
  verifyPayment: publicProcedure
    .input(
      z.object({
        orderId: z.number(),
        status: z.enum(["completed", "failed", "cancelled"]),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const verification = await verifyWisePayment(
          input.orderId,
          input.status
        );
        return {
          success: true,
          verification,
        };
      } catch (error) {
        console.error("Error verifying Wise payment:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Get payment status for an order
   */
  getStatus: protectedProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      try {
        const status = await getWisePaymentStatus(input.orderId);
        return {
          success: true,
          status,
        };
      } catch (error) {
        console.error("Error getting Wise payment status:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Cancel a payment session
   */
  cancelSession: protectedProcedure
    .input(z.object({ orderId: z.number() }))
    .mutation(async ({ input }) => {
      try {
        await cancelWisePaymentSession(input.orderId);
        return {
          success: true,
          message: "Payment session cancelled",
        };
      } catch (error) {
        console.error("Error cancelling Wise payment session:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Get Wise payment configuration
   */
  getConfig: publicProcedure.query(() => {
    try {
      const config = getWisePaymentConfig();
      return {
        success: true,
        config,
      };
    } catch (error) {
      console.error("Error getting Wise payment config:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),

  /**
   * Webhook endpoint for Wise payment notifications
   */
  webhook: publicProcedure
    .input(z.object({ orderId: z.number(), status: z.string() }))
    .mutation(async ({ input }) => {
      try {
        // Validate webhook (in production, verify signature)
        const status = input.status as "completed" | "failed" | "cancelled";
        const verification = await verifyWisePayment(input.orderId, status);

        return {
          success: true,
          verification,
        };
      } catch (error) {
        console.error("Error processing Wise webhook:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),
});

export default wiseRouter;
