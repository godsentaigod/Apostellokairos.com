import * as db from "./db";
import { storagePut, storageGet } from "./storage";
import { sendProductDeliveryEmail } from "./email-service";

export interface ProductDeliveryResult {
  success: boolean;
  productId: number;
  productName: string;
  downloadUrl?: string;
  downloadToken?: string;
  expiresAt?: Date;
  message: string;
}

/**
 * Process product delivery after successful payment
 */
export async function deliverProduct(
  userId: number,
  productId: number,
  orderId: number,
  userEmail: string
): Promise<ProductDeliveryResult> {
  try {
    // Get product details
    const product = await db.getProductById(productId);
    if (!product) {
      return {
        success: false,
        productId,
        productName: "Unknown",
        message: "Product not found",
      };
    }

    // Generate unique download token
    const downloadToken = `token_${userId}_${productId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Create product purchase record
    const purchase = await db.createProductPurchase({
      userId,
      productId,
      orderId,
      downloadToken,
      downloadCount: 0,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      purchasedAt: new Date(),
    });

    // Get download URL (if file is stored in S3)
    let downloadUrl = product.fileUrl || "";
    if (product.fileKey) {
      const presignedUrl = await storageGet(product.fileKey);
      if (presignedUrl) {
        downloadUrl = presignedUrl.url;
      }
    }

    // Send delivery email
    await sendProductDeliveryEmail(userId, userEmail, product.name, downloadUrl || "", downloadToken);

    return {
      success: true,
      productId,
      productName: product.name,
      downloadUrl: downloadUrl || undefined,
      downloadToken,
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      message: `${product.name} has been delivered to ${userEmail}`,
    };
  } catch (error) {
    console.error("Error delivering product:", error);
    return {
      success: false,
      productId,
      productName: "Unknown",
      message: error instanceof Error ? error.message : "Delivery failed",
    };
  }
}

/**
 * Process bundle delivery after successful payment
 */
export async function deliverBundle(
  userId: number,
  bundleId: number,
  orderId: number,
  userEmail: string
): Promise<ProductDeliveryResult[]> {
  try {
    // Get bundle details
    const bundle = await db.getBundleBySlug("");
    if (!bundle) {
      return [
        {
          success: false,
          productId: bundleId,
          productName: "Unknown",
          message: "Bundle not found",
        },
      ];
    }

    // Get product IDs from bundle
    const productIds = (bundle.productIds as any) || [];

    // Deliver each product in bundle
    const results = await Promise.all(
      productIds.map((productId: number) => deliverProduct(userId, productId, orderId, userEmail))
    );

    return results;
  } catch (error) {
    console.error("Error delivering bundle:", error);
    return [
      {
        success: false,
        productId: bundleId,
        productName: "Unknown",
        message: error instanceof Error ? error.message : "Bundle delivery failed",
      },
    ];
  }
}

/**
 * Get download link for purchased product
 */
export async function getProductDownloadLink(
  userId: number,
  productId: number
): Promise<{ url: string; expiresAt: Date } | null> {
  try {
    // Check if user has purchased this product
    const purchase = await db.getUserProductPurchase(userId, productId);
    if (!purchase) {
      return null;
    }

    // Check if download link has expired
    if (purchase.expiresAt && new Date() > purchase.expiresAt) {
      return null;
    }

    // Get product details
    const product = await db.getProductById(productId);
    if (!product || !product.fileUrl) {
      return null;
    }

    // Get presigned URL
    let downloadUrl = product.fileUrl || "";
    if (product.fileKey) {
      const presignedUrl = await storageGet(product.fileKey);
      if (presignedUrl) {
        downloadUrl = presignedUrl.url;
      }
    }

    // Increment download count
    await db.updateEmailLog(purchase.id, {
      downloadCount: (purchase.downloadCount || 0) + 1,
      lastDownloadedAt: new Date(),
    });

    return {
      url: downloadUrl,
      expiresAt: purchase.expiresAt || new Date(Date.now() + 24 * 60 * 60 * 1000),
    };
  } catch (error) {
    console.error("Error getting download link:", error);
    return null;
  }
}

/**
 * Get all purchased products for user
 */
export async function getUserPurchasedProducts(userId: number) {
  try {
    const purchases = await db.getUserPurchases(userId);

    const productsWithDetails = await Promise.all(
      purchases.map(async (purchase: any) => {
        const product = await db.getProductById(purchase.productId);
        return {
          ...purchase,
          product,
          canDownload: !purchase.expiresAt || new Date() <= purchase.expiresAt,
        };
      })
    );

    return productsWithDetails;
  } catch (error) {
    console.error("Error getting purchased products:", error);
    return [];
  }
}

/**
 * Track download analytics
 */
export async function trackDownload(userId: number, productId: number, downloadToken: string) {
  try {
    const purchase = await db.getPurchaseByToken(downloadToken);
    if (!purchase) {
      return { success: false, message: "Invalid download token" };
    }

    // Verify user owns this purchase
    if (purchase.userId !== userId) {
      return { success: false, message: "Unauthorized" };
    }

    // Update download count
    await db.updateEmailLog(purchase.id, {
      downloadCount: (purchase.downloadCount || 0) + 1,
      lastDownloadedAt: new Date(),
    });

    return { success: true, message: "Download tracked" };
  } catch (error) {
    console.error("Error tracking download:", error);
    return { success: false, message: "Tracking failed" };
  }
}
