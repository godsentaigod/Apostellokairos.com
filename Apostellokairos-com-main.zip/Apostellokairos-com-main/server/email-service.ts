import { notifyOwner } from "./_core/notification";
import * as db from "./db";

export interface EmailTemplate {
  type: "welcome" | "order_confirmation" | "product_delivery" | "download_link" | "receipt" | "support";
  subject: string;
  html: string;
  text: string;
}

/**
 * Send welcome email to new customer
 */
export async function sendWelcomeEmail(userId: number, email: string, name?: string) {
  try {
    const template: EmailTemplate = {
      type: "welcome",
      subject: "Welcome to Vibe Coding Command Center",
      html: `
        <h1>Welcome to Vibe Coding!</h1>
        <p>Hi ${name || "there"},</p>
        <p>Thank you for joining Vibe Coding Command Center. You now have access to our premium AI-powered business tools and frameworks.</p>
        <p>Get started by:</p>
        <ul>
          <li>Browsing our product catalog</li>
          <li>Purchasing your first toolkit</li>
          <li>Accessing your downloads immediately</li>
        </ul>
        <p>Questions? Reply to this email or visit our support center.</p>
        <p>Best regards,<br/>Vibe Coding Team</p>
      `,
      text: `Welcome to Vibe Coding!\n\nHi ${name || "there"},\n\nThank you for joining. Get started by browsing our products and making your first purchase.\n\nBest regards,\nVibe Coding Team`,
    };

    await logEmail(userId, email, template);
    await notifyOwner({
      title: "New User Registration",
      content: `${name || email} has joined Vibe Coding Command Center`,
    });

    return { success: true, type: "welcome" };
  } catch (error) {
    console.error("Error sending welcome email:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}

/**
 * Send order confirmation email
 */
export async function sendOrderConfirmationEmail(
  userId: number,
  email: string,
  orderId: number,
  amount: number,
  items: Array<{ name: string; price: number }>
) {
  try {
    const itemsHtml = items.map((item) => `<li>${item.name} - $${item.price}</li>`).join("");

    const template: EmailTemplate = {
      type: "order_confirmation",
      subject: `Order Confirmation #${orderId}`,
      html: `
        <h1>Order Confirmed!</h1>
        <p>Thank you for your purchase.</p>
        <h2>Order Details</h2>
        <p><strong>Order ID:</strong> ${orderId}</p>
        <p><strong>Amount:</strong> $${amount}</p>
        <h3>Items:</h3>
        <ul>${itemsHtml}</ul>
        <p>Your products are ready for download. Check your dashboard or look for the download link below.</p>
        <p>Best regards,<br/>Vibe Coding Team</p>
      `,
      text: `Order Confirmation #${orderId}\n\nThank you for your purchase.\n\nOrder ID: ${orderId}\nAmount: $${amount}\n\nItems:\n${items.map((i) => `- ${i.name}: $${i.price}`).join("\n")}\n\nBest regards,\nVibe Coding Team`,
    };

    await logEmail(userId, email, template, orderId);
    await notifyOwner({
      title: "New Order Received",
      content: `Order #${orderId} for $${amount} from ${email}`,
    });

    return { success: true, type: "order_confirmation" };
  } catch (error) {
    console.error("Error sending order confirmation:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}

/**
 * Send product delivery email with download link
 */
export async function sendProductDeliveryEmail(
  userId: number,
  email: string,
  productName: string,
  downloadUrl: string,
  downloadToken: string
) {
  try {
    const template: EmailTemplate = {
      type: "product_delivery",
      subject: `Your ${productName} is Ready to Download`,
      html: `
        <h1>Your Product is Ready!</h1>
        <p>Your purchase of <strong>${productName}</strong> is ready to download.</p>
        <p><a href="${downloadUrl}?token=${downloadToken}" style="background-color: #8B4C6F; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Download Now</a></p>
        <p>This link will remain active for 30 days. You can also access your downloads anytime from your dashboard.</p>
        <p>Enjoy your new tools!</p>
        <p>Best regards,<br/>Vibe Coding Team</p>
      `,
      text: `Your ${productName} is Ready!\n\nDownload: ${downloadUrl}?token=${downloadToken}\n\nThis link remains active for 30 days.\n\nBest regards,\nVibe Coding Team`,
    };

    await logEmail(userId, email, template);
    return { success: true, type: "product_delivery" };
  } catch (error) {
    console.error("Error sending product delivery email:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}

/**
 * Send receipt email
 */
export async function sendReceiptEmail(
  userId: number,
  email: string,
  orderId: number,
  amount: number,
  items: Array<{ name: string; price: number }>
) {
  try {
    const itemsHtml = items.map((item) => `<tr><td>${item.name}</td><td>$${item.price}</td></tr>`).join("");

    const template: EmailTemplate = {
      type: "receipt",
      subject: `Receipt for Order #${orderId}`,
      html: `
        <h1>Receipt</h1>
        <p><strong>Order ID:</strong> ${orderId}</p>
        <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
        <table style="width: 100%; border-collapse: collapse;">
          <tr style="border-bottom: 1px solid #ddd;">
            <th style="text-align: left; padding: 10px;">Item</th>
            <th style="text-align: right; padding: 10px;">Price</th>
          </tr>
          ${itemsHtml}
          <tr style="border-top: 2px solid #333; font-weight: bold;">
            <td style="padding: 10px;">Total</td>
            <td style="text-align: right; padding: 10px;">$${amount}</td>
          </tr>
        </table>
        <p>Thank you for your business!</p>
      `,
      text: `Receipt for Order #${orderId}\n\nDate: ${new Date().toLocaleDateString()}\n\n${items.map((i) => `${i.name}: $${i.price}`).join("\n")}\n\nTotal: $${amount}\n\nThank you!`,
    };

    await logEmail(userId, email, template, orderId);
    return { success: true, type: "receipt" };
  } catch (error) {
    console.error("Error sending receipt:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}

/**
 * Log email in database
 */
async function logEmail(userId: number, email: string, template: EmailTemplate, orderId?: number) {
  try {
    // This would be implemented with actual database call
    // For now, we log to console and track in database
    console.log(`[EMAIL] Sending ${template.type} to ${email}`);

    // In production, this would save to emailLogs table
    // await db.createEmailLog({
    //   userId,
    //   email,
    //   emailType: template.type,
    //   subject: template.subject,
    //   orderId,
    //   status: "sent",
    //   sentAt: new Date(),
    // });
  } catch (error) {
    console.error("Error logging email:", error);
  }
}

/**
 * Send support email
 */
export async function sendSupportEmail(userId: number, email: string, subject: string, message: string) {
  try {
    const template: EmailTemplate = {
      type: "support",
      subject: `Support Request: ${subject}`,
      html: `
        <h1>Support Request Received</h1>
        <p>We've received your support request and will respond within 24 hours.</p>
        <h3>Your Message:</h3>
        <p>${message.replace(/\n/g, "<br/>")}</p>
        <p>Best regards,<br/>Vibe Coding Support Team</p>
      `,
      text: `Support Request Received\n\nWe've received your request and will respond within 24 hours.\n\nYour Message:\n${message}\n\nBest regards,\nVibe Coding Support Team`,
    };

    await logEmail(userId, email, template);
    await notifyOwner({
      title: "New Support Request",
      content: `Support request from ${email}: ${subject}`,
    });

    return { success: true, type: "support" };
  } catch (error) {
    console.error("Error sending support email:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
