import { invokeLLM } from "../_core/llm";
import * as db from "../db";

export interface AgentStatus {
  agentRole: string;
  status: "idle" | "active" | "processing" | "error";
  lastActivity: Date;
  tasksCompleted: number;
  tasksInProgress: number;
  errorCount: number;
}

export interface ManagerCommand {
  action: "start" | "stop" | "pause" | "resume" | "check_status" | "get_report" | "send_command";
  agentRole?: string;
  command?: string;
  priority?: "low" | "medium" | "high" | "critical";
}

export interface OperationalReport {
  timestamp: Date;
  totalAgents: number;
  activeAgents: number;
  totalTasksCompleted: number;
  totalTasksInProgress: number;
  totalErrors: number;
  revenuGenerated: number;
  conversionRate: number;
  averageOrderValue: number;
  systemHealth: "excellent" | "good" | "fair" | "poor";
}

/**
 * Manager Agent - Coordinates all autonomous agents and operations
 * Responsible for:
 * - Monitoring agent status
 * - Distributing tasks
 * - Handling escalations
 * - Generating reports
 * - Optimizing operations
 */
export class ManagerAgent {
  private agentStatuses: Map<string, AgentStatus> = new Map();
  private operationalMetrics = {
    totalRevenue: 0,
    totalOrders: 0,
    totalCustomers: 0,
    conversionRate: 0,
    averageOrderValue: 0,
  };

  constructor() {
    this.initializeAgents();
  }

  private initializeAgents() {
    const agents = [
      "management",
      "trend-predictor",
      "content-creator",
      "sales-agent",
      "operations-agent",
      "strategy-agent",
      "advanced-coder",
      "platform-architect",
    ];

    agents.forEach((agent) => {
      this.agentStatuses.set(agent, {
        agentRole: agent,
        status: "idle",
        lastActivity: new Date(),
        tasksCompleted: 0,
        tasksInProgress: 0,
        errorCount: 0,
      });
    });
  }

  /**
   * Get all agent statuses
   */
  async getAllAgentStatuses(): Promise<AgentStatus[]> {
    return Array.from(this.agentStatuses.values());
  }

  /**
   * Get specific agent status
   */
  async getAgentStatus(agentRole: string): Promise<AgentStatus | null> {
    return this.agentStatuses.get(agentRole) || null;
  }

  /**
   * Update agent status
   */
  async updateAgentStatus(agentRole: string, updates: Partial<AgentStatus>) {
    const current = this.agentStatuses.get(agentRole);
    if (current) {
      this.agentStatuses.set(agentRole, { ...current, ...updates });
    }
  }

  /**
   * Process manager command
   */
  async processCommand(command: ManagerCommand): Promise<any> {
    switch (command.action) {
      case "start":
        return this.startAgent(command.agentRole!);
      case "stop":
        return this.stopAgent(command.agentRole!);
      case "pause":
        return this.pauseAgent(command.agentRole!);
      case "resume":
        return this.resumeAgent(command.agentRole!);
      case "check_status":
        return this.getAllAgentStatuses();
      case "get_report":
        return this.generateOperationalReport();
      case "send_command":
        return this.sendCommandToAgent(command.agentRole!, command.command!, command.priority);
      default:
        throw new Error(`Unknown command: ${command.action}`);
    }
  }

  /**
   * Start an agent
   */
  private async startAgent(agentRole: string) {
    await this.updateAgentStatus(agentRole, {
      status: "active",
      lastActivity: new Date(),
    });

    return {
      success: true,
      message: `${agentRole} agent started`,
      agent: this.agentStatuses.get(agentRole),
    };
  }

  /**
   * Stop an agent
   */
  private async stopAgent(agentRole: string) {
    await this.updateAgentStatus(agentRole, {
      status: "idle",
      lastActivity: new Date(),
    });

    return {
      success: true,
      message: `${agentRole} agent stopped`,
      agent: this.agentStatuses.get(agentRole),
    };
  }

  /**
   * Pause an agent
   */
  private async pauseAgent(agentRole: string) {
    const status = this.agentStatuses.get(agentRole);
    if (status?.tasksInProgress === 0) {
      await this.updateAgentStatus(agentRole, { status: "idle" });
    } else {
      await this.updateAgentStatus(agentRole, { status: "processing" });
    }

    return {
      success: true,
      message: `${agentRole} agent paused`,
      agent: this.agentStatuses.get(agentRole),
    };
  }

  /**
   * Resume an agent
   */
  private async resumeAgent(agentRole: string) {
    await this.updateAgentStatus(agentRole, {
      status: "active",
      lastActivity: new Date(),
    });

    return {
      success: true,
      message: `${agentRole} agent resumed`,
      agent: this.agentStatuses.get(agentRole),
    };
  }

  /**
   * Send command to specific agent
   */
  private async sendCommandToAgent(agentRole: string, command: string, priority?: string) {
    const status = this.agentStatuses.get(agentRole);
    if (!status) {
      throw new Error(`Agent ${agentRole} not found`);
    }

    // Update agent status to processing
    await this.updateAgentStatus(agentRole, {
      status: "processing",
      tasksInProgress: (status.tasksInProgress || 0) + 1,
      lastActivity: new Date(),
    });

    // Simulate agent processing
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are the ${agentRole} agent. Process this command and provide a concise response.`,
          },
          {
            role: "user",
            content: command,
          },
        ],
      });

      // Update agent status to completed
      const updated = this.agentStatuses.get(agentRole)!;
      await this.updateAgentStatus(agentRole, {
        status: "idle",
        tasksCompleted: (updated.tasksCompleted || 0) + 1,
        tasksInProgress: Math.max(0, (updated.tasksInProgress || 1) - 1),
        lastActivity: new Date(),
      });

      return {
        success: true,
        agent: agentRole,
        command,
        response: response.choices[0]?.message?.content || "No response",
        priority,
      };
    } catch (error) {
      const updated = this.agentStatuses.get(agentRole)!;
      await this.updateAgentStatus(agentRole, {
        status: "error",
        errorCount: (updated.errorCount || 0) + 1,
        tasksInProgress: Math.max(0, (updated.tasksInProgress || 1) - 1),
        lastActivity: new Date(),
      });

      throw error;
    }
  }

  /**
   * Generate operational report
   */
  async generateOperationalReport(): Promise<OperationalReport> {
    const statuses = Array.from(this.agentStatuses.values());
    const activeAgents = statuses.filter((s) => s.status === "active").length;
    const totalTasksCompleted = statuses.reduce((sum, s) => sum + s.tasksCompleted, 0);
    const totalTasksInProgress = statuses.reduce((sum, s) => sum + s.tasksInProgress, 0);
    const totalErrors = statuses.reduce((sum, s) => sum + s.errorCount, 0);

    // Determine system health
    let systemHealth: "excellent" | "good" | "fair" | "poor" = "excellent";
    if (totalErrors > 10) systemHealth = "poor";
    else if (totalErrors > 5) systemHealth = "fair";
    else if (totalErrors > 0) systemHealth = "good";

    return {
      timestamp: new Date(),
      totalAgents: statuses.length,
      activeAgents,
      totalTasksCompleted,
      totalTasksInProgress,
      totalErrors,
      revenuGenerated: this.operationalMetrics.totalRevenue,
      conversionRate: this.operationalMetrics.conversionRate,
      averageOrderValue: this.operationalMetrics.averageOrderValue,
      systemHealth,
    };
  }

  /**
   * Update operational metrics (called when orders are placed)
   */
  async updateMetrics(orderAmount: number) {
    this.operationalMetrics.totalRevenue += orderAmount;
    this.operationalMetrics.totalOrders += 1;
    this.operationalMetrics.averageOrderValue = this.operationalMetrics.totalRevenue / this.operationalMetrics.totalOrders;
  }

  /**
   * Get all agents for dashboard display
   */
  async getAgentsForDashboard() {
    const statuses = await this.getAllAgentStatuses();
    const report = await this.generateOperationalReport();

    return {
      agents: statuses.map((s) => ({
        id: s.agentRole,
        name: this.formatAgentName(s.agentRole),
        status: s.status,
        tasksCompleted: s.tasksCompleted,
        tasksInProgress: s.tasksInProgress,
        errorCount: s.errorCount,
        lastActivity: s.lastActivity,
      })),
      metrics: report,
    };
  }

  private formatAgentName(role: string): string {
    return role
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  }
}

// Export singleton instance
export const managerAgent = new ManagerAgent();
