/**
 * Stripe Payment Agent
 * Autonomous payment processing, revenue tracking, and financial operations
 * Integrates with Sales Blitz for conversion optimization
 */

import { protectedProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import * as db from "../db";
import * as stripePayment from "../stripe-payment";
import Stripe from "stripe";
import { z } from "zod";

const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : (null as any);

interface PaymentMetrics {
  totalRevenue: number;
  totalTransactions: number;
  successfulTransactions: number;
  failedTransactions: number;
  averageOrderValue: number;
  conversionRate: number;
  refundRate: number;
  topProducts: Array<{ productId: number; name: string; revenue: number; units: number }>;
  revenueByDay: Array<{ date: string; revenue: number; transactions: number }>;
}

interface StripePaymentAgentStatus {
  isActive: boolean;
  lastSync: Date;
  metrics: PaymentMetrics;
  pendingOrders: number;
  failedOrders: number;
  totalCustomers: number;
  nextAction: string;
}

/**
 * Calculate payment metrics from database
 */
async function calculatePaymentMetrics(): Promise<PaymentMetrics> {
  try {
    // Get all orders from database
    const db_instance = await db.getDb();
    if (!db_instance) {
      return {
        totalRevenue: 0,
        totalTransactions: 0,
        successfulTransactions: 0,
        failedTransactions: 0,
        averageOrderValue: 0,
        conversionRate: 0,
        refundRate: 0,
        topProducts: [],
        revenueByDay: [],
      };
    }

    // Query all orders
    const orders = await (db_instance.query as any).orders.findMany();

    let totalRevenue = 0;
    let successfulTransactions = 0;
    let failedTransactions = 0;
    const productRevenue: Map<number, { name: string; revenue: number; units: number }> = new Map();
    const dailyRevenue: Map<string, { revenue: number; transactions: number }> = new Map();

    for (const order of orders) {
      const amount = parseFloat(order.totalAmount?.toString() || "0");
      totalRevenue += amount;

      if (order.status === "completed") {
        successfulTransactions++;
      } else if (order.status === "failed") {
        failedTransactions++;
      }

      // Track by product
      if (order.products && Array.isArray(order.products)) {
        for (const product of order.products as any[]) {
          const prodId = product.productId || 0;
          const existing = productRevenue.get(prodId) || { name: product.name || "", revenue: 0, units: 0 };
          existing.revenue += product.price * product.quantity;
          existing.units += product.quantity;
          productRevenue.set(prodId, existing);
        }
      }

      // Track by day
      const orderDate = order.createdAt instanceof Date ? order.createdAt : new Date(order.createdAt || Date.now());
      const date = orderDate.toISOString().split("T")[0];
      const daily = dailyRevenue.get(date) || { revenue: 0, transactions: 1 };
      daily.revenue += amount;
      daily.transactions += 1;
      dailyRevenue.set(date, daily);
    }

    const topProducts = Array.from(productRevenue.values())
      .sort((a: any, b: any) => b.revenue - a.revenue)
      .slice(0, 5)
      .map((p: any, idx: any) => ({
        productId: idx,
        name: p.name,
        revenue: p.revenue,
        units: p.units,
      }));

    const revenueByDay = Array.from(dailyRevenue.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, data]) => ({
        date,
        revenue: data.revenue,
        transactions: data.transactions,
      }));

    const totalTransactions = successfulTransactions + failedTransactions;
    const conversionRate = totalTransactions > 0 ? (successfulTransactions / totalTransactions) * 100 : 0;
    const averageOrderValue = successfulTransactions > 0 ? totalRevenue / successfulTransactions : 0;

    return {
      totalRevenue,
      totalTransactions,
      successfulTransactions,
      failedTransactions,
      averageOrderValue,
      conversionRate,
      refundRate: 0, // TODO: Calculate from refunded orders
      topProducts,
      revenueByDay,
    };
  } catch (error) {
    console.error("Error calculating payment metrics:", error);
    return {
      totalRevenue: 0,
      totalTransactions: 0,
      successfulTransactions: 0,
      failedTransactions: 0,
      averageOrderValue: 0,
      conversionRate: 0,
      refundRate: 0,
      topProducts: [],
      revenueByDay: [],
    };
  }
}

/**
 * Generate AI insights on payment performance
 */
async function generatePaymentInsights(metrics: PaymentMetrics): Promise<string> {
  try {
    const prompt = `Analyze these payment metrics and provide actionable insights for revenue optimization:

Total Revenue: $${metrics.totalRevenue.toFixed(2)}
Total Transactions: ${metrics.totalTransactions}
Successful: ${metrics.successfulTransactions}
Failed: ${metrics.failedTransactions}
Conversion Rate: ${metrics.conversionRate.toFixed(2)}%
Average Order Value: $${metrics.averageOrderValue.toFixed(2)}
Refund Rate: ${metrics.refundRate.toFixed(2)}%

Top Products:
${metrics.topProducts.map((p) => `- ${p.name}: $${p.revenue.toFixed(2)} (${p.units} units)`).join("\n")}

Provide 3-5 specific recommendations to increase revenue and reduce failed transactions.`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are a payment optimization expert. Analyze metrics and provide actionable insights.",
        },
        { role: "user", content: prompt },
      ],
    });

    const content = response.choices[0]?.message.content;
    return typeof content === "string" ? content : "Unable to generate insights";
  } catch (error) {
    console.error("Error generating insights:", error);
    return "Error generating insights";
  }
}

/**
 * Monitor and optimize payment flow
 */
async function monitorPaymentFlow(): Promise<void> {
  try {
    // Check for pending orders
    const db_instance = await db.getDb();
    const orders = db_instance ? (await (db_instance.query as any).orders.findMany()) : [] as any[];
    const pendingOrders = orders.filter((o: any) => o.status === "pending");

    if (pendingOrders.length > 0) {
      console.log(`[Stripe Agent] Found ${pendingOrders.length} pending orders, verifying with Stripe...`);

      for (const order of pendingOrders) {
        // Verify payment status with Stripe
        try {
          const sessions = await stripe.checkout.sessions.list({ limit: 100 });
          const session = sessions.data.find((s: any) => s.metadata?.orderId === order.id?.toString());

          if (session && session.payment_status === "paid") {
            await db.updateOrderStatus(order.id || 0, "completed");
            console.log(`[Stripe Agent] Order ${order.id} marked as completed`);
          }
        } catch (error) {
          console.error(`Error verifying order ${order.id}:`, error);
        }
      }
    }

    // Check for failed orders
    const failedOrders = orders.filter((o: any) => o.status === "failed");
    if (failedOrders.length > 0) {
      console.log(`[Stripe Agent] Found ${failedOrders.length} failed orders, analyzing...`);
      // TODO: Send retry emails or notifications
    }
  } catch (error) {
    console.error("Error monitoring payment flow:", error);
  }
}

/**
 * Get agent status
 */
async function getAgentStatus(): Promise<StripePaymentAgentStatus> {
  const metrics = await calculatePaymentMetrics();
  const db_instance = await db.getDb();
  const orders = db_instance ? (await (db_instance.query as any).orders.findMany()) : [] as any[];

  return {
    isActive: !!stripe,
    lastSync: new Date(),
    metrics,
    pendingOrders: orders.filter((o: any) => o.status === "pending").length,
    failedOrders: orders.filter((o: any) => o.status === "failed").length,
    totalCustomers: new Set(orders.map((o: any) => o.guestEmail || o.userId)).size,
    nextAction: "Monitoring payment flow and optimizing conversion rates",
  };
}

/**
 * Stripe Payment Agent Router
 */
export const stripePaymentAgentRouter = router<any>({
  /**
   * Get payment metrics and performance
   */
  getMetrics: protectedProcedure.query(async () => {
    return await calculatePaymentMetrics();
  }),

  /**
   * Get AI-generated insights on payment performance
   */
  getInsights: protectedProcedure.query(async () => {
    const metrics = await calculatePaymentMetrics();
    const insights = await generatePaymentInsights(metrics);
    return { metrics, insights };
  }),

  /**
   * Get agent status and operational info
   */
  getStatus: protectedProcedure.query(async () => {
    return await getAgentStatus();
  }),

  /**
   * Manually trigger payment flow monitoring
   */
  monitorPayments: protectedProcedure.mutation(async () => {
    await monitorPaymentFlow();
    return { success: true, message: "Payment monitoring completed" };
  }),

  /**
   * Get recent transactions
   */
  getRecentTransactions: protectedProcedure
    .input(z.object({ limit: z.number().optional().default(10) }))
    .query(async ({ input }) => {
      const db_instance = await db.getDb();
      const orders = db_instance ? (await (db_instance.query as any).orders.findMany()) : [] as any[];
      return orders.slice(-input.limit).reverse();
    }),

  /**
   * Get revenue report
   */
  getRevenueReport: protectedProcedure
    .input(z.object({ days: z.number().optional().default(30) }))
    .query(async ({ input }) => {
      const metrics = await calculatePaymentMetrics();
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - input.days);

      const filteredRevenue = metrics.revenueByDay.filter((d: any) => new Date(d.date) >= cutoffDate);

      return {
        period: `Last ${input.days} days`,
        totalRevenue: filteredRevenue.reduce((sum, d) => sum + d.revenue, 0),
        totalTransactions: filteredRevenue.reduce((sum, d) => sum + d.transactions, 0),
        dailyData: filteredRevenue,
      };
    }),

  /**
   * Get customer insights
   */
  getCustomerInsights: protectedProcedure.query(async () => {
    const db_instance = await db.getDb();
    const orders = db_instance ? (await (db_instance.query as any).orders.findMany()) : [] as any[];
    const customers = new Map<string, { orders: number; revenue: number; lastOrder: Date }>();

    for (const order of orders as any[]) {
      const email = order.guestEmail || `user_${order.userId}`;
      const existing = customers.get(email) || { orders: 0, revenue: 0, lastOrder: new Date(0) };
      existing.orders += 1;
      existing.revenue += parseFloat(order.totalAmount?.toString() || "0");
      const orderDate = order.createdAt instanceof Date ? order.createdAt : new Date(order.createdAt || Date.now());
      existing.lastOrder = orderDate;
      customers.set(email, existing);
    }

    const customerList = Array.from(customers.entries())
      .map(([email, data]) => ({ email, ...data }))
      .sort((a, b) => b.revenue - a.revenue);

    return {
      totalCustomers: customers.size,
      topCustomers: customerList.slice(0, 10),
      averageOrdersPerCustomer: orders.length / (customers.size || 1),
      averageCustomerValue: customers.size > 0 ? Array.from(customers.values()).reduce((sum, c) => sum + c.revenue, 0) / customers.size : 0,
    };
  }),
});
