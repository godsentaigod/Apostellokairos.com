import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { managerAgent, ManagerCommand } from "./manager-agent";
import * as db from "../db";

export const managerRouter = router({
  /**
   * Get all agent statuses
   */
  getAgentStatuses: protectedProcedure.query(async () => {
    return managerAgent.getAllAgentStatuses();
  }),

  /**
   * Get specific agent status
   */
  getAgentStatus: protectedProcedure
    .input(z.object({ agentRole: z.string() }))
    .query(async ({ input }) => {
      return managerAgent.getAgentStatus(input.agentRole);
    }),

  /**
   * Get dashboard data (agents + metrics)
   */
  getDashboard: protectedProcedure.query(async () => {
    return managerAgent.getAgentsForDashboard();
  }),

  /**
   * Send command to manager agent
   */
  sendCommand: protectedProcedure
    .input(
      z.object({
        action: z.enum(["start", "stop", "pause", "resume", "check_status", "get_report", "send_command"]),
        agentRole: z.string().optional(),
        command: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const managerCommand: ManagerCommand = {
        action: input.action as any,
        agentRole: input.agentRole,
        command: input.command,
        priority: input.priority,
      };

      try {
        return await managerAgent.processCommand(managerCommand);
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Command failed",
        });
      }
    }),

  /**
   * Get operational report
   */
  getOperationalReport: protectedProcedure.query(async () => {
    return managerAgent.generateOperationalReport();
  }),

  /**
   * Start all agents
   */
  startAllAgents: adminProcedure.mutation(async () => {
    const statuses = await managerAgent.getAllAgentStatuses();
    const results = [];

    for (const status of statuses) {
      const result = await managerAgent.processCommand({
        action: "start",
        agentRole: status.agentRole,
      });
      results.push(result);
    }

    return {
      success: true,
      message: "All agents started",
      results,
    };
  }),

  /**
   * Stop all agents
   */
  stopAllAgents: adminProcedure.mutation(async () => {
    const statuses = await managerAgent.getAllAgentStatuses();
    const results = [];

    for (const status of statuses) {
      const result = await managerAgent.processCommand({
        action: "stop",
        agentRole: status.agentRole,
      });
      results.push(result);
    }

    return {
      success: true,
      message: "All agents stopped",
      results,
    };
  }),

  /**
   * Get agent conversation history
   */
  getConversationHistory: protectedProcedure
    .input(z.object({ conversationId: z.number() }))
    .query(async ({ input }) => {
      // This would fetch from database
      return {
        conversationId: input.conversationId,
        messages: [],
      };
    }),

  /**
   * Create new conversation with agent
   */
  createConversation: protectedProcedure
    .input(
      z.object({
        agentRole: z.string(),
        title: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");

      // Create conversation in database
      return {
        conversationId: Math.floor(Math.random() * 10000),
        agentRole: input.agentRole,
        title: input.title || `Chat with ${input.agentRole}`,
        createdAt: new Date(),
      };
    }),

  /**
   * Send message to agent in conversation
   */
  sendMessage: protectedProcedure
    .input(
      z.object({
        conversationId: z.number(),
        agentRole: z.string(),
        message: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) throw new Error("Not authenticated");

      // Send command to agent
      const result = await managerAgent.processCommand({
        action: "send_command",
        agentRole: input.agentRole,
        command: input.message,
      });

      return {
        conversationId: input.conversationId,
        userMessage: input.message,
        agentResponse: result.response,
        timestamp: new Date(),
      };
    }),

  /**
   * Get sales metrics
   */
  getSalesMetrics: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) throw new Error("Not authenticated");

    const orders = await db.getUserOrders(ctx.user.id);
    const totalRevenue = orders.reduce((sum: number, order: any) => sum + parseFloat(order.amount.toString()), 0);
    const totalOrders = orders.length;
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    return {
      totalRevenue,
      totalOrders,
      averageOrderValue,
      conversionRate: 0,
      topProducts: [],
      recentOrders: orders.slice(-10),
    };
  }),

  /**
   * Get customer metrics
   */
  getCustomerMetrics: adminProcedure.query(async () => {
    return {
      totalCustomers: 0,
      returningCustomers: 0,
      newCustomers: 0,
      customerRetentionRate: 0,
    };
  }),

  /**
   * Get product performance
   */
  getProductPerformance: adminProcedure.query(async () => {
    const products = await db.getAllProducts();
    return products.map((product: any) => ({
      id: product.id,
      name: product.name,
      totalSales: 0,
      totalRevenue: 0,
      averageRating: 4.5,
    }));
  }),
});
