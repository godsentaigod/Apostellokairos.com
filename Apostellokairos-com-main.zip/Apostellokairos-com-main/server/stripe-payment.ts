/**
 * Stripe Payment Integration Service
 * Official payment gateway with fully branded checkout experience
 */

import Stripe from "stripe";
import * as db from "./db";

// Initialize Stripe with API key from environment
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : (null as any);

export interface StripeCheckoutSession {
  sessionId: string;
  orderId: number;
  userId?: number;
  guestEmail?: string;
  products: Array<{ productId: number; quantity: number; price: number }>;
  totalAmount: number;
  currency: string;
  checkoutUrl: string;
  createdAt: Date;
  expiresAt: Date;
}

export interface StripePaymentVerification {
  orderId: number;
  status: "pending" | "completed" | "failed" | "cancelled";
  amount: number;
  currency: string;
  paymentIntentId: string;
  verifiedAt?: Date;
}

/**
 * Create a branded Stripe checkout session
 */
export async function createStripeCheckoutSession(
  products: Array<{ productId: number; quantity: number }>,
  options?: {
    userId?: number;
    guestEmail?: string;
    guestName?: string;
    returnUrl?: string;
  }
): Promise<StripeCheckoutSession> {
  if (!stripe) {
    throw new Error("Stripe is not configured. Please set STRIPE_SECRET_KEY environment variable.");
  }
  try {
    // Fetch product details and calculate totals
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [];
    let totalAmount = 0;
    const productDetails = [];

    for (const item of products) {
      // Get product from database
      const product = await db.getProductById(item.productId);
      if (!product) {
        throw new Error(`Product ${item.productId} not found`);
      }

      const price = parseFloat(product.price?.toString() || "0");
      const priceInCents = Math.round(price * 100);
      totalAmount += priceInCents * item.quantity;

      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: {
            name: product.name,
            description: product.description || "",
            images: product.image ? [product.image] : [],
            metadata: {
              productId: product.id?.toString() || "",
              category: product.category || "",
            },
          },
          unit_amount: priceInCents,
        },
        quantity: item.quantity,
      });

      productDetails.push({
        productId: product.id || 0,
        name: product.name,
        quantity: item.quantity,
        price: priceInCents / 100,
      });
    }

    // Create order in database
    const orderResult = await db.createOrder({
      userId: options?.userId,
      guestEmail: options?.guestEmail,
      guestName: options?.guestName,
      totalAmount: totalAmount / 100,
      currency: "USD",
      status: "pending",
      products: productDetails,
    });

    // Extract order ID from result
    const orderId = typeof orderResult === "object" && "id" in orderResult
      ? (orderResult as any).id
      : typeof orderResult === "number"
      ? orderResult
      : 0;

    // Create Stripe checkout session
    const sessionParams: Stripe.Checkout.SessionCreateParams = {
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: `${options?.returnUrl || process.env.VITE_APP_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}&order_id=${orderId}`,
      cancel_url: `${options?.returnUrl || process.env.VITE_APP_URL}/checkout/cancelled?order_id=${orderId}`,
      customer_email: options?.guestEmail,
      metadata: {
        orderId: orderId.toString(),
        userId: options?.userId?.toString() || "guest",
      },
      // Branded checkout experience
      billing_address_collection: "required",
      payment_intent_data: {
        metadata: {
          orderId: orderId.toString(),
          userId: options?.userId?.toString() || "guest",
        },
      },
    };

    const session = await stripe.checkout.sessions.create(sessionParams);

    if (!session.url) {
      throw new Error("Failed to generate Stripe checkout URL");
    }

    return {
      sessionId: session.id,
      orderId: orderId,
      userId: options?.userId,
      guestEmail: options?.guestEmail,
      products: productDetails,
      totalAmount: totalAmount / 100,
      currency: "USD",
      checkoutUrl: session.url,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    };
  } catch (error) {
    console.error("Stripe checkout session creation error:", error);
    throw error;
  }
}

/**
 * Verify payment and update order status
 */
export async function verifyStripePayment(
  sessionId: string
): Promise<StripePaymentVerification> {
  if (!stripe) {
    throw new Error("Stripe is not configured.");
  }
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (!session.metadata?.orderId) {
      throw new Error("Order ID not found in session metadata");
    }

    const stripeOrderId = parseInt(session.metadata.orderId);
    let status: "pending" | "completed" | "failed" | "cancelled" = "pending";

    if (session.payment_status === "paid") {
      status = "completed";
      // Update order status in database
      await db.updateOrderStatus(stripeOrderId, "completed");
    } else if (session.payment_status === "unpaid") {
      status = "pending";
    } else {
      status = "failed";
      await db.updateOrderStatus(stripeOrderId, "failed");
    }

    return {
      orderId: stripeOrderId,
      status,
      amount: (session.amount_total || 0) / 100,
      currency: session.currency?.toUpperCase() || "USD",
      paymentIntentId: session.payment_intent?.toString() || "",
      verifiedAt: new Date(),
    };
  } catch (error) {
    console.error("Stripe payment verification error:", error);
    throw error;
  }
}

/**
 * Get payment status for an order
 */
export async function getPaymentStatus(
  orderId: number
): Promise<StripePaymentVerification | null> {
  if (!stripe) {
    return null;
  }
  try {
    const order = await db.getOrderById(orderId);
    if (!order) {
      return null;
    }

    // Search for Stripe session by order ID
    const sessions = await stripe.checkout.sessions.list({
      limit: 1,
    });

    const session = sessions.data.find(
      (s: any) => s.metadata?.orderId === orderId.toString()
    );

    if (!session) {
      return null;
    }

    return await verifyStripePayment(session.id);
  } catch (error) {
    console.error("Error getting payment status:", error);
    return null;
  }
}

/**
 * Handle Stripe webhook events
 */
export async function handleStripeWebhook(
  event: Stripe.Event
): Promise<void> {
  if (!stripe) {
    throw new Error("Stripe is not configured.");
  }
  try {
    switch (event.type) {
      case "checkout.session.completed":
        const session = event.data.object as Stripe.Checkout.Session;
        if (session.metadata?.orderId) {
          const completedOrderId = parseInt(session.metadata.orderId);
          await db.updateOrderStatus(completedOrderId, "completed");
          // TODO: Send confirmation email
          console.log(`Order ${completedOrderId} payment completed`);
        }
        break;

      case "charge.failed":
        const charge = event.data.object as Stripe.Charge;
        if (charge.metadata?.orderId) {
          const failedOrderId = parseInt(charge.metadata.orderId);
          await db.updateOrderStatus(failedOrderId, "failed");
          console.log(`Order ${failedOrderId} payment failed`);
        }
        break;

      case "charge.refunded":
        const refundedCharge = event.data.object as Stripe.Charge;
        if (refundedCharge.metadata?.orderId) {
          const refundedOrderId = parseInt(refundedCharge.metadata.orderId);
          await db.updateOrderStatus(refundedOrderId, "refunded");
          console.log(`Order ${refundedOrderId} refunded`);
        }
        break;
    }
  } catch (error) {
    console.error("Stripe webhook error:", error);
    throw error;
  }
}

/**
 * Cancel a checkout session
 */
export async function cancelCheckoutSession(sessionId: string): Promise<void> {
  if (!stripe) {
    throw new Error("Stripe is not configured.");
  }
  try {
    await stripe.checkout.sessions.expire(sessionId);
  } catch (error) {
    console.error("Error cancelling checkout session:", error);
    throw error;
  }
}

/**
 * Get Stripe publishable key for frontend
 */
export function getStripePublishableKey(): string {
  const key = process.env.STRIPE_PUBLISHABLE_KEY;
  if (!key) {
    throw new Error("STRIPE_PUBLISHABLE_KEY not configured");
  }
  return key;
}
