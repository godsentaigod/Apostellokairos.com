import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, AlertCircle, ExternalLink, ArrowLeft, Lock } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

interface CartItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
}

export default function StripeCheckout() {
  const [, setLocation] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success" | "error">("idle");
  const [checkoutUrl, setCheckoutUrl] = useState<string>("");
  const [orderId, setOrderId] = useState<number | null>(null);
  
  // Guest info
  const [guestEmail, setGuestEmail] = useState("");
  const [guestName, setGuestName] = useState("");
  const [emailError, setEmailError] = useState("");

  // Load cart from localStorage and query params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("product");
    const bundleId = params.get("bundle");

    if (productId || bundleId) {
      // Load single product from query param
      const id = productId ? parseInt(productId) : bundleId ? parseInt(bundleId) : null;
      if (id) {
        setCartItems([{
          productId: id,
          name: "",
          price: 0,
          quantity: 1,
        }]);
      }
    } else {
      // Load cart from localStorage
      const cart = localStorage.getItem("cart");
      if (cart) {
        try {
          setCartItems(JSON.parse(cart));
        } catch (e) {
          console.error("Failed to parse cart:", e);
        }
      }
    }
  }, []);

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.1;
  const total = subtotal + tax;

  // Validate email
  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  // Create Stripe checkout session
  const createCheckout = trpc.stripe.createSession.useMutation();

  const handleCheckout = async () => {
    setEmailError("");

    if (!guestName.trim()) {
      setEmailError("Name is required");
      return;
    }

    if (!guestEmail.trim()) {
      setEmailError("Email is required");
      return;
    }

    if (!validateEmail(guestEmail)) {
      setEmailError("Please enter a valid email");
      return;
    }

    if (cartItems.length === 0) {
      setEmailError("Cart is empty");
      return;
    }

    setIsLoading(true);
    setPaymentStatus("processing");

    try {
      const result = await createCheckout.mutateAsync({
        products: cartItems.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
        })),
        guestEmail,
        guestName,
        returnUrl: window.location.origin,
      });

      if (result.success && result.session) {
        setOrderId(result.session.orderId);
        setCheckoutUrl(result.session.checkoutUrl);
        setPaymentStatus("success");
        // Clear cart
        localStorage.removeItem("cart");
      } else {
        setPaymentStatus("error");
        setEmailError(result.error || "Failed to create checkout session");
      }
    } catch (error) {
      console.error("Checkout error:", error);
      setPaymentStatus("error");
      setEmailError("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/50 py-12">
      <div className="container max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <Link href="/products">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Products
            </Button>
          </Link>
          <h1 className="text-4xl font-bold text-foreground mb-2">Secure Payment</h1>
          <p className="text-muted-foreground">Complete your purchase with Stripe - the world's leading payment platform</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Order Summary */}
          <div className="lg:col-span-2">
            <Card className="border-border/50 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Review your items before payment</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {cartItems.length > 0 ? (
                    <>
                      {cartItems.map((item) => (
                        <div key={item.productId} className="flex items-center justify-between pb-4 border-b border-border/30">
                          <div className="flex-1">
                            <h3 className="font-semibold text-foreground">{item.name || `Product #${item.productId}`}</h3>
                            <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-foreground">${(item.price * item.quantity).toFixed(2)}</p>
                            <p className="text-xs text-muted-foreground">${item.price.toFixed(2)} each</p>
                          </div>
                        </div>
                      ))}

                      {/* Pricing Details */}
                      <div className="mt-6 pt-6 border-t border-border/30 space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Subtotal</span>
                          <span className="font-medium text-foreground">${subtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Tax (10%)</span>
                          <span className="font-medium text-foreground">${tax.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center pt-3 border-t border-border/30">
                          <span className="text-lg font-bold text-foreground">Total</span>
                          <span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground mb-4">Your cart is empty</p>
                      <Link href="/products">
                        <Button>Browse Products</Button>
                      </Link>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Section */}
          <div>
            <Card className="border-border/50 shadow-lg sticky top-8">
              <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Secure Checkout
                </CardTitle>
                <CardDescription>Powered by Stripe</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                {paymentStatus === "idle" && (
                  <div className="space-y-4">
                    {/* Guest Info Form */}
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium text-foreground">Full Name</label>
                        <Input
                          type="text"
                          placeholder="John Doe"
                          value={guestName}
                          onChange={(e) => setGuestName(e.target.value)}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-foreground">Email Address</label>
                        <Input
                          type="email"
                          placeholder="you@example.com"
                          value={guestEmail}
                          onChange={(e) => {
                            setGuestEmail(e.target.value);
                            setEmailError("");
                          }}
                          disabled={isLoading}
                          className="mt-1"
                        />
                      </div>
                    </div>

                    {emailError && (
                      <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-sm text-red-800">{emailError}</p>
                      </div>
                    )}

                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-900">
                        You will be redirected to Stripe to complete your payment securely.
                      </p>
                    </div>

                    <Button
                      onClick={handleCheckout}
                      disabled={isLoading || cartItems.length === 0}
                      className="w-full h-12 text-base font-semibold bg-primary hover:bg-primary/90"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          Pay ${total.toFixed(2)} with Stripe
                        </>
                      )}
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() => setLocation("/products")}
                      className="w-full"
                    >
                      Continue Shopping
                    </Button>
                  </div>
                )}

                {paymentStatus === "processing" && (
                  <div className="text-center py-8">
                    <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground">Preparing your payment...</p>
                  </div>
                )}

                {paymentStatus === "success" && checkoutUrl && (
                  <div className="space-y-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-green-900">Order Created</p>
                          <p className="text-sm text-green-800 mt-1">
                            Order #{orderId} is ready for payment
                          </p>
                        </div>
                      </div>
                    </div>

                    <a
                      href={checkoutUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block"
                    >
                      <Button className="w-full h-12 text-base font-semibold bg-primary hover:bg-primary/90" size="lg">
                        Complete Payment on Stripe
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </a>

                    <div className="text-xs text-muted-foreground text-center">
                      You will be redirected to Stripe to complete your secure payment
                    </div>
                  </div>
                )}

                {paymentStatus === "error" && (
                  <div className="space-y-4">
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-red-900">Payment Error</p>
                          <p className="text-sm text-red-800 mt-1">
                            Failed to create payment session. Please try again.
                          </p>
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={handleCheckout}
                      className="w-full"
                      size="lg"
                    >
                      Try Again
                    </Button>
                  </div>
                )}

                {/* Security Badges */}
                <div className="mt-6 pt-6 border-t border-border/30">
                  <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="text-xs">
                      🔒 PCI Compliant
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      ✓ Secure
                    </Badge>
                  </div>
                  <p className="text-xs text-center text-muted-foreground mt-2">
                    Trusted by millions worldwide
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
