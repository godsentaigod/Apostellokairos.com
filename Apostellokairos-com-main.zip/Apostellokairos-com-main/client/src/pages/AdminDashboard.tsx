import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Loader2, Send, Play, Pause, RotateCcw, Activity } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [selectedAgent, setSelectedAgent] = useState<string>("management");
  const [loading, setLoading] = useState(false);

  // Redirect if not admin
  useEffect(() => {
    if (user && user.role !== "admin") {
      setLocation("/");
    }
  }, [user, setLocation]);

  // Fetch dashboard data
  const { data: dashboard, isLoading: dashboardLoading, refetch } = trpc.manager?.getDashboard?.useQuery?.() || { data: undefined, isLoading: false, refetch: () => {} };
    const { data: report } = trpc.manager?.getOperationalReport?.useQuery?.() || { data: undefined };
    const { data: salesMetrics } = trpc.manager?.getSalesMetrics?.useQuery?.() || { data: undefined };

  // Mutations
  const sendCommand = trpc.manager.sendCommand.useMutation();
  const startAllAgents = trpc.manager.startAllAgents.useMutation();
  const stopAllAgents = trpc.manager.stopAllAgents.useMutation();

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setLoading(true);
    try {
      await sendCommand.mutateAsync({
        action: "send_command",
        agentRole: selectedAgent,
        command: message,
      });
      setMessage("");
      refetch();
    } catch (error) {
      console.error("Error sending command:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleStartAll = async () => {
    try {
      await startAllAgents.mutateAsync();
      refetch();
    } catch (error) {
      console.error("Error starting agents:", error);
    }
  };

  const handleStopAll = async () => {
    try {
      await stopAllAgents.mutateAsync();
      refetch();
    } catch (error) {
      console.error("Error stopping agents:", error);
    }
  };

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access this page.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-gradient-to-r from-primary/10 to-secondary/10 border-b py-8">
        <div className="container">
          <h1 className="text-4xl font-bold mb-2">Autonomous Operations Command Center</h1>
          <p className="text-muted-foreground">Manage AI agents and monitor real-time operations</p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Metrics Cards */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${report?.revenuGenerated.toFixed(2) || "0.00"}</div>
              <p className="text-xs text-muted-foreground mt-1">From all orders</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Agents</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{report?.activeAgents || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">Out of {report?.totalAgents}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Tasks Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{report?.totalTasksCompleted || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">{report?.totalTasksInProgress || 0} in progress</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <Badge
                variant={
                  report?.systemHealth === "excellent"
                    ? "default"
                    : report?.systemHealth === "good"
                      ? "secondary"
                      : "destructive"
                }
              >
                {report?.systemHealth || "Unknown"}
              </Badge>
              <p className="text-xs text-muted-foreground mt-2">{report?.totalErrors || 0} errors</p>
            </CardContent>
          </Card>
        </div>

        {/* Agent Management */}
        <div className="container mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Agent List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Agents</CardTitle>
              <CardDescription>Manage autonomous workforce</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex gap-2 mb-4">
                <Button size="sm" onClick={handleStartAll} disabled={dashboardLoading} className="flex-1">
                  <Play className="w-4 h-4 mr-1" /> Start All
                </Button>
                <Button size="sm" variant="outline" onClick={handleStopAll} disabled={dashboardLoading} className="flex-1">
                  <Pause className="w-4 h-4 mr-1" /> Stop All
                </Button>
              </div>

              {dashboardLoading ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
              ) : (
                <div className="space-y-2">
                  {dashboard?.agents?.map?.((agent: any) => (
                    <div
                      key={agent.id}
                      onClick={() => setSelectedAgent(agent.id)}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedAgent === agent.id ? "bg-primary/10 border-primary" : "hover:bg-muted"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{agent.name}</span>
                        <Badge
                          variant={
                            agent.status === "active"
                              ? "default"
                              : agent.status === "error"
                                ? "destructive"
                                : "secondary"
                          }
                          className="text-xs"
                        >
                          {agent.status}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        <Activity className="w-3 h-3 inline mr-1" />
                        {agent.tasksCompleted} completed
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Chat Interface */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Manager Communication</CardTitle>
              <CardDescription>Send commands to {dashboard?.agents?.find?.((a: any) => a.id === selectedAgent)?.name}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col h-96">
              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto mb-4 p-4 bg-muted/30 rounded-lg border">
                <div className="space-y-3">
                  <div className="flex justify-end">
                    <div className="bg-primary text-primary-foreground rounded-lg px-3 py-2 max-w-xs text-sm">
                      Start monitoring sales performance
                    </div>
                  </div>
                  <div className="flex justify-start">
                    <div className="bg-muted text-muted-foreground rounded-lg px-3 py-2 max-w-xs text-sm">
                      Sales monitoring active. Current conversion rate: 3.2%. Trend: +0.5% from yesterday.
                    </div>
                  </div>
                </div>
              </div>

              {/* Input */}
              <form onSubmit={handleSendMessage} className="flex gap-2">
                <Input
                  placeholder="Send command to agent..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  disabled={loading}
                />
                <Button type="submit" disabled={loading || !message.trim()}>
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Sales Metrics */}
        <div className="container mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Sales Performance</CardTitle>
              <CardDescription>Real-time metrics and revenue tracking</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Revenue</p>
                  <p className="text-2xl font-bold">${salesMetrics?.totalRevenue.toFixed(2) || "0.00"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total Orders</p>
                  <p className="text-2xl font-bold">{salesMetrics?.totalOrders || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Avg Order Value</p>
                  <p className="text-2xl font-bold">${salesMetrics?.averageOrderValue.toFixed(2) || "0.00"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Conversion Rate</p>
                  <p className="text-2xl font-bold">{salesMetrics?.conversionRate.toFixed(1) || "0.0"}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
