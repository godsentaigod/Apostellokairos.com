import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, AlertCircle, ExternalLink } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

interface CartItem {
  productId: number;
  name: string;
  price: number;
  quantity: number;
}

export default function WiseCheckout() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "processing" | "success" | "error">("idle");
  const [wiseLink, setWiseLink] = useState<string>("");
  const [orderId, setOrderId] = useState<number | null>(null);

  // Load cart from localStorage
  useEffect(() => {
    const cart = localStorage.getItem("cart");
    if (cart) {
      try {
        setCartItems(JSON.parse(cart));
      } catch (e) {
        console.error("Failed to parse cart:", e);
      }
    }
  }, []);

  // Redirect if not authenticated
  useEffect(() => {
    if (!user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + tax;

  // Create Wise payment session
  const createSession = trpc.wise.createSession.useMutation();

  const handleCheckout = async () => {
    if (!user || cartItems.length === 0) return;

    setIsLoading(true);
    setPaymentStatus("processing");

    try {
      const result = await createSession.mutateAsync({
        products: cartItems.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
        })),
      });

      if (result.success && result.session) {
        setOrderId(result.session.orderId);
        setWiseLink(result.session.wiseLink);
        setPaymentStatus("success");
      } else {
        setPaymentStatus("error");
      }
    } catch (error) {
      console.error("Checkout error:", error);
      setPaymentStatus("error");
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/50 py-12">
      <div className="container max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Secure Checkout</h1>
          <p className="text-muted-foreground">Complete your purchase with Wise</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Order Summary */}
          <div className="lg:col-span-2">
            <Card className="border-border/50 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
                <CardTitle>Order Summary</CardTitle>
                <CardDescription>Review your items before payment</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div key={item.productId} className="flex items-center justify-between pb-4 border-b border-border/30">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">{item.name}</h3>
                        <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-foreground">${(item.price * item.quantity).toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">${item.price.toFixed(2)} each</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pricing Details */}
                <div className="mt-6 pt-6 border-t border-border/30 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-medium text-foreground">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Tax (10%)</span>
                    <span className="font-medium text-foreground">${tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center pt-3 border-t border-border/30">
                    <span className="text-lg font-bold text-foreground">Total</span>
                    <span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Section */}
          <div>
            <Card className="border-border/50 shadow-lg sticky top-8">
              <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10">
                <CardTitle>Payment Method</CardTitle>
                <CardDescription>Powered by Wise</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                {paymentStatus === "idle" && (
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-900">
                        You will be redirected to Wise to complete your payment securely.
                      </p>
                    </div>

                    <Button
                      onClick={handleCheckout}
                      disabled={isLoading || cartItems.length === 0}
                      className="w-full h-12 text-base font-semibold"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          Pay ${total.toFixed(2)} with Wise
                        </>
                      )}
                    </Button>

                    <Button
                      variant="outline"
                      onClick={() => setLocation("/products")}
                      className="w-full"
                    >
                      Continue Shopping
                    </Button>
                  </div>
                )}

                {paymentStatus === "processing" && (
                  <div className="text-center py-8">
                    <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground">Preparing your payment...</p>
                  </div>
                )}

                {paymentStatus === "success" && wiseLink && (
                  <div className="space-y-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-green-900">Order Created</p>
                          <p className="text-sm text-green-800 mt-1">
                            Order #{orderId} is ready for payment
                          </p>
                        </div>
                      </div>
                    </div>

                    <a
                      href={wiseLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block"
                    >
                      <Button className="w-full h-12 text-base font-semibold" size="lg">
                        Complete Payment on Wise
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </a>

                    <div className="text-xs text-muted-foreground text-center">
                      You will be redirected to Wise to complete your secure payment
                    </div>
                  </div>
                )}

                {paymentStatus === "error" && (
                  <div className="space-y-4">
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="font-semibold text-red-900">Payment Error</p>
                          <p className="text-sm text-red-800 mt-1">
                            Failed to create payment session. Please try again.
                          </p>
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={handleCheckout}
                      className="w-full"
                      size="lg"
                    >
                      Try Again
                    </Button>
                  </div>
                )}

                {/* Security Badge */}
                <div className="mt-6 pt-6 border-t border-border/30">
                  <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="text-xs">
                      🔒 Secure Payment
                    </Badge>
                  </div>
                  <p className="text-xs text-center text-muted-foreground mt-2">
                    Your payment information is secure and encrypted
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
