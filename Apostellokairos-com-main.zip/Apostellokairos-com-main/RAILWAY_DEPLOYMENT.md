# Railway Deployment Guide

## Prerequisites
- Railway CLI installed
- GitHub repository connected
- Environment variables configured

## Environment Variables Required

```
DATABASE_URL=postgresql://user:password@host:5432/db
JWT_SECRET=your-jwt-secret
VITE_APP_ID=your-manus-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
OWNER_OPEN_ID=your-owner-id
OWNER_NAME=Your Name
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-forge-api-key
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
STRIPE_PUBLIC_KEY=pk_live_your_key
STRIPE_SECRET_KEY=sk_live_your_key
STRIPE_WEBHOOK_SECRET=whsec_your_secret
NODE_ENV=production
```

## Deployment Steps

1. **Connect Repository**
   ```bash
   railway link
   ```

2. **Set Environment Variables**
   ```bash
   railway variables set DATABASE_URL=...
   railway variables set JWT_SECRET=...
   # ... set all variables above
   ```

3. **Deploy**
   ```bash
   railway deploy
   ```

4. **View Logs**
   ```bash
   railway logs
   ```

## Custom Domain Setup

1. Go to Railway project settings
2. Add custom domain: therealityarchitech.xyz
3. Update DNS records with Railway's nameservers
4. Wait for DNS propagation (5-30 minutes)

## Post-Deployment Testing

- Visit https://therealityarchitech.xyz
- Test login flow
- Test product checkout
- Verify Command Center access
