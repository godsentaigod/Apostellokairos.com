# Stripe Setup for Payment Processing

## Step 1: Get Your Stripe Keys

1. Go to https://dashboard.stripe.com
2. Sign in to your Stripe account
3. Navigate to Developers → API Keys
4. Copy your keys:
   - **Publishable Key** (starts with `pk_live_` or `pk_test_`)
   - **Secret Key** (starts with `sk_live_` or `sk_test_`)

## Step 2: Get Webhook Secret

1. In Stripe Dashboard, go to Developers → Webhooks
2. Create a new endpoint or use existing one
3. Point to: `https://yourdomain.com/api/trpc/checkout.handleWebhook`
4. Copy the **Signing Secret** (starts with `whsec_`)

## Step 3: Configure in Manus

The Stripe keys are built-in secrets that must be configured through the Manus Management UI:

1. Go to Project Settings → Secrets
2. Add the following environment variables:
   - `STRIPE_PUBLIC_KEY` = your pk_live_... or pk_test_...
   - `STRIPE_SECRET_KEY` = your sk_live_... or sk_test_...
   - `STRIPE_WEBHOOK_SECRET` = your whsec_...

## Step 4: Test Keys

Use Stripe test keys first to verify everything works:
- Test Card: 4242 4242 4242 4242
- Exp: 12/25, CVC: 123

## Step 5: Switch to Live Keys

Once testing is complete, replace test keys with live keys for production.

